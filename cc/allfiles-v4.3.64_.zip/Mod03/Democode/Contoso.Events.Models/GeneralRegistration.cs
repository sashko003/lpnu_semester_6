﻿namespace Contoso.Events.Models
{
    public class GeneralRegistration
    {
        public string EventKey { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}