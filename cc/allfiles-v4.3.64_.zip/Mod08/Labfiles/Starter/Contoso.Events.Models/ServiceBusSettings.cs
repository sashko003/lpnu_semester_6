﻿namespace Contoso.Events.Models
{
    public class ServiceBusSettings
    {
        public string ConnectionString { get; set; }

        public string QueueName { get; set; }
    }
}